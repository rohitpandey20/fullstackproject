const express = require('express');
const app = express();
const port = 2000;

// Serve static files from the "public" directory
app.use(express.static('public'));

// Set EJS as the template engine
app.set('view engine', 'ejs');

// Middleware to parse URL-encoded data
app.use(express.urlencoded({ extended: true }));

// Render the HTML form
app.get('/', (req, res) => {
    res.render('index');
});

// Handle form submission
app.post('/submit-form', (req, res) => {
    const { name, email } = req.body;
    console.log(`Name: ${name}, Email: ${email}`);
    res.send(`Thank you, ${name}! Your email (${email}) has been received.`);
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
